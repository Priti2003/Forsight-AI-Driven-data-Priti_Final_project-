from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[1]))

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from src.forecast import make_features, FEATURES

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/"data/processed/weekly_sku.csv"
MODEL=ROOT/"models/forecast_model.joblib"
app=FastAPI(title="FORESIGHT Scoring Service", version="1.0")

class ScoreRequest(BaseModel):
    sku: str

@app.get("/health")
def health():
    return {"status":"ok"}

@app.post("/score")
def score(req: ScoreRequest):
    if not DATA.exists() or not MODEL.exists():
        raise HTTPException(500, "Run python run_pipeline.py first.")
    df=pd.read_csv(DATA,parse_dates=["week"])
    x=make_features(df)
    rows=x[x["Product ID"]==req.sku].dropna(subset=FEATURES)
    if rows.empty:
        raise HTTPException(404, "SKU not found or insufficient history.")
    latest=rows.iloc[-1:]
    model=joblib.load(MODEL)
    pred=float(model.predict(latest[FEATURES])[0])
    inventory=float(latest["inventory"].iloc[0])
    risk="STOCKOUT RISK" if inventory < pred*1.2 else ("OVERSTOCK RISK" if inventory > pred*6 else "HEALTHY")
    action={"STOCKOUT RISK":"REORDER NOW","OVERSTOCK RISK":"MARKDOWN / CLEAR","HEALTHY":"NO ACTION"}[risk]
    return {"sku":req.sku,"forecast_units":round(pred,2),"inventory":round(inventory,2),
            "risk":risk,"recommended_action":action}
