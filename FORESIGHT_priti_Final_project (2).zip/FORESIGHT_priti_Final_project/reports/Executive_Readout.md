# Executive Readout — Project FORESIGHT

**Prepared by: Vivek**

## 1. Business problem
The goal is to reduce stockouts and excess inventory by turning historical retail data into demand forecasts and transparent stocking actions.

## 2. Dataset
73,100 daily observations, 20 products and 5 stores, covering 2022-01-01 to 2024-01-01.

## 3. Forecast performance
The Random Forest model was evaluated using three rolling-origin 8-week folds.

- Fold 1: 8.71% WAPE vs 14.34% seasonal-naive
- Fold 2: 9.10% WAPE vs 16.98% seasonal-naive
- Fold 3: 19.56% WAPE vs 26.22% seasonal-naive

The model beat the seasonal-naive baseline in every fold.

## 4. Recommended operating actions
- Reorder products where projected demand plus safety allowance exceeds available inventory.
- Markdown/clear products where inventory materially exceeds projected demand.
- Keep healthy products unchanged.
- Review volatile products manually rather than automating purchases.

## 5. Dashboard
The Streamlit dashboard exposes SKU/category filters, demand history, forecast, inventory and a priority planning table.

## 6. Caveats
The Kaggle source is a single table rather than the four source extracts described in the original Zidio brief. It also lacks reliable unit-cost and lead-time fields. Therefore the project does not claim a precise finance-grade capital-at-risk figure; those fields should be added when real client extracts become available.
