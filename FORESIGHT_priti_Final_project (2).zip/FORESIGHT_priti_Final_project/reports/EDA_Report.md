# Data Quality & EDA Insight Memo

## Dataset
The supplied Kaggle file contains 73,100 rows from 2022-01-01 through 2024-01-01, covering 20 products and 5 stores.

## Data quality
- No missing values were detected in the supplied raw extract.
- Duplicate rows were removed in the reproducible pipeline.
- Date and numeric fields are explicitly coerced.
- Weekly product gaps are represented explicitly before feature engineering.

## Business observations
1. **Demand is spread across five major categories.** Furniture is the highest-volume category in the supplied data, followed by Groceries and Clothing.
2. **P0016 is the highest-volume product**, with more than 508k units sold over the full period.
3. **Promotions matter materially:** approximately 4.96 million units were sold on rows marked as promotional/holiday, so promotion signals should be retained in the forecasting pipeline.
4. **Inventory planning is measurable at weekly SKU level:** the dataset provides both units sold and inventory level, allowing a transparent stock-risk layer.

## Modelling implication
The dataset contains roughly two years of daily history, making a 52-week seasonal-naive comparison possible. The project therefore uses lag-52 as the baseline and rolling-origin validation rather than a random split.
