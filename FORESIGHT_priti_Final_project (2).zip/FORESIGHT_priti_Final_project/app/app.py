import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))

import streamlit as st
import pandas as pd
import numpy as np
import joblib
from src.forecast import make_features, FEATURES

st.set_page_config(page_title="FORESIGHT", page_icon="📦", layout="wide")
st.title("📦 FORESIGHT — Demand & Inventory Intelligence")
st.caption("NorthBay Living | Zidio Data Science Project | Prepared by Vivek")

DATA = Path(__file__).resolve().parents[1]/"data/processed/weekly_sku.csv"
MODEL = Path(__file__).resolve().parents[1]/"models/forecast_model.joblib"

if not DATA.exists():
    st.error("Processed data not found. Run: python run_pipeline.py")
    st.stop()

df = pd.read_csv(DATA, parse_dates=["week"])
x = make_features(df)
if MODEL.exists():
    model = joblib.load(MODEL)
    usable = x.dropna(subset=FEATURES).copy()
    usable["forecast"] = model.predict(usable[FEATURES])
else:
    usable = x.dropna(subset=FEATURES).copy()
    usable["forecast"] = usable["lag_52"]

latest = usable["week"].max()
latest_df = usable[usable["week"]==latest].copy()

c1,c2,c3,c4 = st.columns(4)
c1.metric("Latest weekly units", f"{latest_df.units_sold.sum():,.0f}")
c2.metric("Forecast next comparable week", f"{latest_df.forecast.sum():,.0f}")
c3.metric("SKUs", f"{latest_df['Product ID'].nunique():,}")
c4.metric("Categories", f"{latest_df.category.nunique():,}")

st.sidebar.header("Filters")
cats = ["All"] + sorted(latest_df.category.dropna().unique().tolist())
cat = st.sidebar.selectbox("Category", cats)
sku_options = sorted(latest_df["Product ID"].unique())
sku = st.sidebar.selectbox("SKU", ["All"] + sku_options)

view = latest_df.copy()
if cat != "All": view = view[view.category==cat]
if sku != "All": view = view[view["Product ID"]==sku]

st.subheader("Demand trend")
trend = usable[usable["Product ID"].isin(view["Product ID"].unique())]
chart = trend.pivot_table(index="week", columns="Product ID", values=["units_sold","forecast"], aggfunc="sum")
st.line_chart(chart)

st.subheader("Priority planning view")
table = view[["Product ID","category","units_sold","forecast","inventory","ordered","price"]].copy()
table["forecast_gap"] = table["forecast"] - table["inventory"] - table["ordered"]
table["action"] = np.select(
    [table.forecast_gap > 0.5*table.forecast,
     table.inventory > 1.5*table.forecast],
    ["REORDER NOW","MARKDOWN / CLEAR"], default="HEALTHY"
)
st.dataframe(table.sort_values("forecast_gap", ascending=False), use_container_width=True)

st.info("Risk logic is intentionally transparent: projected demand is compared with available stock and a safety factor. This supports, rather than automates, purchasing decisions.")
