"""
FORESIGHT data pipeline
Converts the Kaggle retail inventory extract into a clean weekly SKU dataset.
"""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw" / "retail_store_inventory.csv"
OUT = ROOT / "data" / "processed" / "weekly_sku.csv"

def run_pipeline():
    df = pd.read_csv(RAW)
    df.columns = [c.strip() for c in df.columns]
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    numeric = ["Inventory Level","Units Sold","Units Ordered","Demand Forecast",
               "Price","Discount","Competitor Pricing","Holiday/Promotion"]
    for c in numeric:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.drop_duplicates()
    df = df.dropna(subset=["Date","Product ID","Units Sold"])
    for c in numeric:
        df[c] = df[c].fillna(df[c].median())
    df["week"] = df["Date"].dt.to_period("W-SUN").dt.end_time.dt.normalize()

    weekly = (df.groupby(["week","Product ID"], as_index=False)
        .agg(units_sold=("Units Sold","sum"),
             inventory=("Inventory Level","mean"),
             ordered=("Units Ordered","sum"),
             price=("Price","mean"),
             discount=("Discount","mean"),
             promo=("Holiday/Promotion","max"),
             category=("Category","first"),
             region=("Region","first")))
    weekly = weekly.sort_values(["Product ID","week"])

    # Complete the product-week grid so zero-sales weeks are explicit.
    weeks = pd.date_range(weekly["week"].min(), weekly["week"].max(), freq="W-SUN")
    skus = weekly["Product ID"].unique()
    grid = pd.MultiIndex.from_product([weeks, skus], names=["week","Product ID"]).to_frame(index=False)
    weekly = grid.merge(weekly, on=["week","Product ID"], how="left")
    for c in ["units_sold","inventory","ordered","price","discount","promo"]:
        weekly[c] = weekly[c].fillna(0)
    weekly["category"] = weekly.groupby("Product ID")["category"].ffill().bfill()
    weekly["region"] = weekly.groupby("Product ID")["region"].ffill().bfill()
    OUT.parent.mkdir(parents=True, exist_ok=True)
    weekly.to_csv(OUT, index=False)
    return weekly

if __name__ == "__main__":
    out = run_pipeline()
    print(f"Saved {len(out):,} rows to {OUT}")
