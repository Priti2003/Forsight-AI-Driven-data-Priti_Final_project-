"""
FORESIGHT forecasting model.
Weekly SKU demand, seasonal-naive baseline, rolling-origin backtest.
"""
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT/"data/processed/weekly_sku.csv"
MODEL_DIR = ROOT/"models"
MODEL_DIR.mkdir(exist_ok=True)

FEATURES = [
    "lag_1","lag_2","lag_4","lag_8","lag_13","lag_52",
    "roll_4","roll_8","roll_13",
    "inventory","ordered","price","discount","promo",
    "weekofyear","month","trend"
]

def wape(y, pred):
    denom = np.abs(y).sum()
    return float(np.abs(np.asarray(y)-np.asarray(pred)).sum()/denom) if denom else 0.0

def make_features(df):
    x = df.copy().sort_values(["Product ID","week"])
    for lag in [1,2,4,8,13,52]:
        x[f"lag_{lag}"] = x.groupby("Product ID")["units_sold"].shift(lag)
    for win in [4,8,13]:
        x[f"roll_{win}"] = x.groupby("Product ID")["units_sold"].transform(
            lambda s: s.shift(1).rolling(win).mean()
        )
    x["weekofyear"] = pd.to_datetime(x["week"]).dt.isocalendar().week.astype(int)
    x["month"] = pd.to_datetime(x["week"]).dt.month
    x["trend"] = x.groupby("Product ID").cumcount()
    return x

def train_and_backtest():
    df = pd.read_csv(DATA, parse_dates=["week"])
    x = make_features(df).dropna(subset=FEATURES).copy()
    max_week = x["week"].max()
    fold_ends = [max_week-pd.Timedelta(weeks=23),
                 max_week-pd.Timedelta(weeks=15),
                 max_week-pd.Timedelta(weeks=7)]
    results = []
    for fold, end in enumerate(fold_ends, 1):
        train = x[x.week < end]
        test = x[(x.week >= end) & (x.week < end+pd.Timedelta(weeks=8))]
        model = RandomForestRegressor(
            n_estimators=150, max_depth=14, min_samples_leaf=2,
            random_state=42, n_jobs=-1
        )
        model.fit(train[FEATURES], train["units_sold"])
        pred = model.predict(test[FEATURES])
        results.append({
            "fold": fold,
            "model_wape": wape(test["units_sold"], pred),
            "baseline_wape": wape(test["units_sold"], test["lag_52"])
        })

    model = RandomForestRegressor(
        n_estimators=250, max_depth=14, min_samples_leaf=2,
        random_state=42, n_jobs=-1
    )
    model.fit(x[FEATURES], x["units_sold"])
    joblib.dump(model, MODEL_DIR/"forecast_model.joblib")
    pd.DataFrame(results).to_csv(MODEL_DIR/"backtest_results.csv", index=False)
    return pd.DataFrame(results)

if __name__ == "__main__":
    print(train_and_backtest().to_string(index=False))
