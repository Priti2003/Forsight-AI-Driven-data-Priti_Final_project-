"""
FORESIGHT inventory risk scoring.
Transparent rules based on forecast demand and current inventory.
"""
import pandas as pd
import numpy as np

def score_risk(df, forecast_weeks=4, safety_factor=1.20):
    x = df.copy()
    x["forecast_4w"] = x["forecast_4w"].clip(lower=0)
    x["lead_time_weeks"] = (x["lead_time_days"]/7).clip(lower=1)
    x["lead_time_demand"] = x["forecast_4w"] * (x["lead_time_weeks"]/forecast_weeks)
    x["available"] = x["on_hand"] + x["on_order"]

    x["stockout_gap"] = x["lead_time_demand"]*safety_factor - x["available"]
    x["stockout_risk"] = (x["stockout_gap"] > 0).astype(int)

    x["excess_units"] = (x["on_hand"] - x["forecast_4w"]*1.5).clip(lower=0)
    x["overstock_risk"] = (x["excess_units"] > 0).astype(int)

    def action(r):
        if r.stockout_risk and not r.overstock_risk: return "REORDER NOW"
        if r.overstock_risk and not r.stockout_risk: return "MARKDOWN / CLEAR"
        if r.stockout_risk and r.overstock_risk: return "WATCH / VOLATILE"
        return "HEALTHY"
    x["action"] = x.apply(action, axis=1)

    x["sales_at_risk"] = x["stockout_gap"].clip(lower=0) * x["unit_price"]
    x["locked_capital"] = x["excess_units"] * x["unit_cost"]
    return x
